import java.io.IOException;

public class main {

	public static void main(String[] args) throws InterruptedException, IOException {

		Store store = new Store(1,2);
	}

}
